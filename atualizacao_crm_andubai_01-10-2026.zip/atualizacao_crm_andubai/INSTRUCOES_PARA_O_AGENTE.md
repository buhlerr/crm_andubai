# Mudanças necessárias no repositório `crm_andubai`

Documento para o agente que mantém este repositório. Leia inteiro antes de começar e siga a ordem
das seções: a 1 e a 2 são urgentes.

## Contexto

Este repositório nasceu do **pacote de teste de 30/09/2026** do sistema "Checklist Pós-Venda" (o
`LEIA-ME.txt` da raiz é o desse pacote). O pacote não levava os testes, o `CLAUDE.md` com as regras
de negócio nem o instalador. Desde então, o sistema original ganhou funções novas, que estão nesta pasta.

**Mantenha tudo o que foi criado aqui:**
- o módulo de Pautas TM;
- o login individual por e-mail e senha;
- a leitura de Excel com calamine;
- Docker, Linux e systemd.

O trabalho é corrigir os problemas abaixo e trazer as funções novas, sem perder nada disso.

Conteúdo desta pasta:
- `INSTRUCOES_PARA_O_AGENTE.md`: este arquivo.
- `codigo/`: os arquivos do sistema original na versão de 01/10/2026, com os mesmos caminhos do repositório.
- `referencia/CLAUDE.md`: as regras de negócio e as decisões do sistema original. Leia antes de mexer
  em importação, filas ou tarefas.

---

## 1. URGENTE: dados reais dentro do repositório

Estes arquivos estão versionados e têm dados reais da Egali, de alunos e de colaboradores:

| Arquivo | O que é |
|---|---|
| `pautaCatListCsv.csv` (6,4 MB) | exportação do TM |
| `pautaList-30_09_2026.csv` | página do TM salva (é HTML, não CSV) |
| `Pautas.mhtml` | página do SharePoint da Egali, com cerca de 170 e-mails |
| `Configuração de Pautas.mhtml` | página do SharePoint, com cerca de 330 e-mails |
| `pautas_home.mhtml` | página do TM salva |

Não abra nem copie o conteúdo desses arquivos para lugar nenhum. O que fazer:

1. **Tirar os arquivos do repositório** (`git rm --cached`). Se servem de base para os testes do leitor
   de pautas, troque por amostras **fictícias e pequenas**, feitas à mão em `tests/amostras/`.
2. **Bloquear no `.gitignore`**, que hoje bloqueia bancos e zips, mas não planilhas nem páginas salvas:
   ```
   *.csv
   *.xlsx
   *.xls
   *.xlsb
   *.xlsm
   *.mhtml
   *.mht
   !tests/amostras/*
   ```
3. **Limpar o histórico do git.** Apagar o arquivo agora não basta: ele continua nos commits antigos.
   Use `git filter-repo --path <arquivo> --invert-paths` para cada um e force o push. **Antes, combine
   com quem administra o repositório**, porque isso reescreve o histórico de todo mundo.
4. **Confirmar se o repositório é privado.** Em 01/10/2026, `github.com/buhlerr/crm_andubai` respondia
   "Page not found" para quem não tinha acesso, o que indica repositório privado. Mesmo assim:
   - mantenha-o privado;
   - revise quem são os colaboradores, porque todos têm acesso a esses dados no histórico;
   - confira se nunca esteve público (configurações do repositório e log de auditoria). Se esteve, avise a pessoa responsável, porque é um incidente de dados pessoais (LGPD), e não só técnico.
5. **Testes:** `tests/test_pautas.py`, linha 83, usa o e-mail real de um colega (domínio egali.com.br).
   Troque por um fictício (`consultor@exemplo.test`). Regra do projeto: testes só com dados fictícios.
6. **Apagar o `LEIA-ME.txt` da raiz.** Ele é o texto do pacote de teste e não se aplica ao repositório.

## 2. URGENTE: segurança do login e das sessões

O sistema é publicado na internet (Cloudflare e Pangolin, segundo o `ESTRUTURA.md`) com dados reais
de alunos. Por isso, estes pontos precisam ser resolvidos antes de qualquer função nova.

1. **Chave das sessões com valor padrão público.**
   - Se `SECRET_KEY` não estiver definida, o `create_app` usa `"dev-troque-em-producao"`.
   - O `servidor.py` recusa subir assim, mas o Docker e o systemd sobem pelo **gunicorn** (`wsgi:app`), que pula essa trava.
   - Com a chave conhecida, qualquer pessoa consegue forjar o cookie de sessão de um administrador.
   - Correção: fazer a recusa no próprio `create_app` (fora dos testes), ou gerar a chave na primeira subida e guardá-la em `<CHECKLIST_DADOS>/secret_key`.
   - O README diz que a chave é "gerada aleatória", o que hoje não é verdade.
2. **Senha da equipe com valor padrão no código.**
   - O `docker-compose.yml` traz um valor padrão para `SENHA_PROVISORIA`, versionado, e o `checklist.service` tem um texto de exemplo no lugar.
   - Correção: sem valor padrão. Se a variável não vier, o sistema não sobe.
   - Como o valor já está no histórico do git, **troque a senha da equipe** em produção.
3. **Login de transição.**
   - Hoje, qualquer usuário sem senha individual entra com e-mail e senha da equipe, e então define a própria senha.
   - Quem souber a senha da equipe e o e-mail de alguém que ainda não definiu senha toma a conta dessa pessoa, inclusive de um administrador.
   - Sugestão:
     - permitir a transição só enquanto `LOGIN_PROVISORIO` estiver ligado, e nunca para o papel admin;
     - o admin define a senha temporária dos outros administradores pela tela (já existe redefinição no CLI);
     - registrar no log cada entrada pela transição.
4. **Tentativas de login:** limite simples por e-mail e por IP, por exemplo 10 tentativas a cada 15 minutos, com a mensagem "Muitas tentativas. Aguarde alguns minutos."
5. **Senha mínima:** subir de 6 para 10 caracteres.
6. **Publicação externa:** a decisão de expor dados de alunos fora da rede é da TI e da área de proteção de dados. Registre no README que isso foi aprovado, e por quem.
7. **O que se vê de fora em `https://crm.vbr.dpdns.org`** (conferido em 01/10/2026, só pela página pública de login, sem tentar entrar):
   - **Domínio e acesso:** a tela de login fica aberta para qualquer pessoa na internet, num domínio gratuito (`dpdns.org`), e não num endereço da Egali.
     - Avaliar com a TI um domínio da empresa e uma barreira antes do login, como o Cloudflare Access ou o próprio Pangolin com SSO da Microsoft, liberando só contas @egali.com.br.
   - **Servidor:** a resposta se identifica como `gunicorn`. Esse é o caminho que pula a trava da `SECRET_KEY` (item 2.1).
     - **Confirme agora que a chave em produção não é a padrão.** Se for, troque: todos terão de entrar de novo.
   - **Cabeçalhos ausentes:** não há `Strict-Transport-Security`, `X-Frame-Options` (ou `frame-ancestors`) nem `X-Content-Type-Options`.
     - Acrescente um `after_request` no `create_app`, com HSTS só quando `ATRAS_DE_PROXY`/HTTPS estiver ligado, `X-Frame-Options: DENY` e `X-Content-Type-Options: nosniff`.
   - **Cloudflare:** não aparece nenhum sinal dele na frente, embora o ESTRUTURA.md diga que há. Corrija a documentação ou a infraestrutura.

## 3. Banco de dados e migrações

1. **O que foi criado aqui não tem migração.**
   - Nenhuma migração cria `usuario.senha_hash` nem as tabelas `pauta`, `pauta_anotacao` e `colaborador_setor`.
   - A coluna de senha é criada por um `ALTER TABLE` dentro do evento de conexão (`_configurar_sqlite`, em `app/__init__.py`), que roda a cada conexão e engole erros.
   - As tabelas de pautas não são criadas por nada fora dos testes. Num banco novo, `flask db upgrade` deixa a tela de Pautas quebrada.
   - Correção, nesta ordem:
     1. copie `codigo/migrations/versions/a750f5567f2c_organizar_por_e_lancamento_na_egali.py`, do sistema original, com `down_revision = 'b863f41b75c9'`;
     2. gere uma migração nova (`flask db migrate -m "senha e pautas"`) com `down_revision = 'a750f5567f2c'`, que crie `senha_hash` e as três tabelas;
     3. escreva essa migração para **não falhar em bancos que já têm a coluna e as tabelas**: confira com `sa.inspect(op.get_bind())` antes de criar;
     4. tire o `ALTER TABLE` do evento de conexão;
     5. confira que `flask db heads` mostra **uma única** cabeça.
   - Padrões das migrações do projeto:
     - `render_as_batch`;
     - boolean com `server_default=sa.false()`, nunca `sa.text('0')`;
     - nomes de constraint com `op.f()`;
     - o autogenerate duplica os CHECK dos enums: mantenha só os `ck_...`.
2. **Dockerfile:** o comando de início é `flask db upgrade && flask catalogo carregar ... || true && gunicorn ...`. Se a migração falhar, o `|| true` engole o erro e o sistema sobe com o banco errado. Separe: se a migração falhar, o container não sobe. Só o `catalogo carregar` pode ser tolerado.
3. **Teste de migrações:** traga `codigo/tests/test_migracoes.py`. Ele roda todas as migrações num banco com dados, e precisa passar com as suas migrações novas.

## 4. Funções novas do sistema original (trazer para cá)

Os arquivos estão em `codigo/`. **Não sobrescreva às cegas.** Nos arquivos marcados com ✱, junte as
duas versões: a nossa traz a função nova, e a daqui tem pautas, senha ou menu, que devem continuar.

| Função | O que faz | Arquivos |
|---|---|---|
| Tipo de visto | "Turista - EUA,eTA - Canadá" (coluna Visto normalizado) vira os selos "Visto - EUA - Turista" e "Visto - Canadá - eTA". Aparece em todas as visões, como filtro e na página do aluno. | `app/vistos.py` (novo), `app/consultas.py`, `app/web/__init__.py` ✱ (filtro de template `vistos`), `_macros.html`, `fila.html`, `programa.html` |
| Organizar por | Lista: agrupa por data prevista, procedimento, visto, embarque, responsável ou status. Quadro: ordena os alunos. Preferência guardada por pessoa. | `app/consultas.py` (`Organizar`, `_ordem`, `agrupar`), `app/web/filas.py`, `app/models/cadastro.py` ✱ (`organizar_lista`, `organizar_quadro`), `fila.html`, `filas/_lista.html` |
| Quadro por aluno em dropdown | Uma linha por aluno, que abre as tarefas. Próximos embarques primeiro, agrupados por mês; no fim, "Embarque já passou". | `filas/_quadro.html`, `app/consultas.py` (`quadro_por_aluno`), `app/static/estilo.css` |
| Concluídas | Tela `/concluidas`, com origem ("Neste sistema", "Saiu do checklist da Egali", "Encerrada à mão"), quem concluiu e se foi no prazo. | `app/consultas.py` (`concluidas`), `app/web/filas.py`, `templates/concluidas.html` (novo), `base.html` ✱ |
| Para lançar na Egali | Tela `/para-lancar`: o que foi concluído ou anotado aqui e ainda precisa ir para o TM, com "Lancei na Egali". A importação seguinte confirma. Contador na barra lateral. | `app/models/tarefas.py` (`lancada_egali_*`), `app/acoes_tarefa.py`, `app/web/tarefas.py`, `app/consultas.py`, `templates/para_lancar.html` (novo), `base.html` ✱, `app/web/__init__.py` ✱ (`topo_para_lancar`), migração `a750f5567f2c` |
| Fora do período | Na página da importação, só vêm marcadas as tarefas com prazo **antes** do período. As de depois continuam pendentes e vêm desmarcadas. | `app/web/importacoes.py`, `templates/importacoes/detalhe.html` |

Cuidados nessa junção:
- As colunas novas que apontam para `usuario` (`lancada_egali_por_id`) obrigam a declarar `foreign_keys=` em `Tarefa.responsavel_manual` e `Anotacao.autor`. Sem isso, o SQLAlchemy dá `AmbiguousForeignKeysError`. Já está feito em `codigo/app/models/tarefas.py`.
- Em `base.html` ✱, mantenha os itens daqui ("Pautas TM", "Pautas e Setores", "Minha Conta" / "Trocar senha" e o atalho no chip do usuário) e acrescente "Concluídas" e "Para lançar na Egali" no grupo "Filas de trabalho".
- Em `app/models/cadastro.py` ✱, mantenha `senha_hash`, `definir_senha` e `verificar_senha`, e acrescente `organizar_lista` e `organizar_quadro`.
- Em `app/web/__init__.py` ✱, mantenha o blueprint `pautas` e acrescente o filtro `vistos` e o `topo_para_lancar`.
- `app/andamento.py` é igual nos dois lados. Só o `tests/test_andamento.py` daqui está desatualizado: use o de `codigo/`.
- `scripts/iniciar_local.ps1` chama `scripts/iniciar_equipe.ps1` quando existe `C:\ChecklistEgali\dados\config.py`. Esse script não existe aqui: tire esse bloco, ou ele quebra numa máquina que tenha essa pasta.

## 5. Testes

Hoje há 10 testes aqui; o sistema original tem 253.

1. Traga a pasta `codigo/tests/` inteira, com `conftest.py`. Todos usam só dados fictícios.
2. **Adapte ao login daqui.** A maioria dos testes já entra gravando `usuario_id` direto na sessão e não depende da tela de login. Os que testam a tela `/entrar` do login provisório (escolher o nome; em `test_web.py` e `test_instalacao.py`) precisam passar a usar e-mail e senha, ou ser trocados pelos seus de `test_auth.py`. Não apague um teste sem pôr outro equivalente no lugar.
3. `test_leitor_excel.py` daqui fica. Se algum teste trazido do original depender do Excel do Windows (automação COM), adapte-o ao calamine em vez de apagar.
4. Meta: `pytest` todo verde. Atualize o AGENTS.md, que hoje fala em "10 testes".

## 6. Documentação

1. **Regras de negócio:** o AGENTS.md só cobre a stack. Leve para ele (ou mantenha um CLAUDE.md ao lado) as regras de `referencia/CLAUDE.md`, que valem para qualquer mudança:
   - correspondência sempre por ID, nunca por nome;
   - a importação nunca sobrescreve o trabalho feito no sistema;
   - toda importação tem prévia antes de confirmar e é idempotente;
   - a NEG fica separada das anotações e só ela conta como justificativa;
   - a data do procedimento é fixa e a planejada não muda o atraso;
   - testes só com dados fictícios;
   - interface em português, sem jargão.
2. **Corrigir o que hoje está errado:**
   - README: a chave "gerada aleatória" (veja 2.1); `LOGIN_PROVISORIO` aparece como padrão `0`, mas o código e o compose usam `1`; o `iniciar.cmd` não cria `.venv` nem usa a porta 8080 (usa a 5000).
   - ESTRUTURA.md: cita um `.env.example` que não existe; a lista de testes e a de modelos não batem com o código.
3. **Registrar as diferenças de propósito em relação ao original:** Linux/Docker em vez de IIS e Windows, calamine em vez do Excel por automação COM e login por senha em vez do Microsoft 365. Assim ninguém "corrige" de volta.

## 7. Como saber que terminou

- [ ] `git ls-files` não mostra nenhum `.csv`, `.xlsx`, `.mhtml` (fora `tests/amostras/`), e o histórico foi limpo, ou a decisão de não limpar ficou registrada.
- [ ] Nenhum valor padrão de senha ou chave no repositório (`docker-compose.yml`, `checklist.service`, `config.py.exemplo`, código).
- [ ] O sistema não sobe sem `SECRET_KEY` real, nem pelo gunicorn.
- [ ] O login de transição não vale para administradores, e há limite de tentativas.
- [ ] A produção tem `SECRET_KEY` própria e a senha da equipe foi trocada. As respostas trazem HSTS, `X-Frame-Options` e `nosniff`.
- [ ] `flask db heads` mostra uma cabeça, e `flask db upgrade` num banco vazio cria todas as tabelas, inclusive as de pautas.
- [ ] O `ALTER TABLE` do evento de conexão foi removido.
- [ ] Concluídas, Para lançar, Organizar por, tipo de visto e quadro em dropdown funcionando, e Pautas continua funcionando.
- [ ] `pytest` todo verde, com os testes trazidos do original adaptados ao login daqui.
- [ ] README, ESTRUTURA e AGENTS atualizados.

Faça em commits separados, nesta ordem: (1) dados, (2) segurança, (3) migrações, (4) funções novas,
(5) testes, (6) documentação. Assim cada parte pode ser revisada sozinha.
