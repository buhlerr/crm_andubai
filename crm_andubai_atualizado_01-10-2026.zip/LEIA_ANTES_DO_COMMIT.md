# crm_andubai: incorporação de 01/10/2026

A pasta `crm_andubai/` é o repositório inteiro já atualizado, a partir do `crm_andubai-master.zip`.
Copie o conteúdo por cima de um clone do repositório e faça os commits abaixo. **Leia a seção
"Antes de publicar"**: algumas coisas não se resolvem no código.

Resultado: **271 testes passando** (eram 10). `flask db heads` mostra uma cabeça só, e a migração foi
testada num banco novo e num banco com os dados do jeito que a versão anterior deixava.

## Antes de publicar (fora do código)

1. **Chave das sessões e senha da equipe estavam no repositório.**
   - O `docker-compose.yml` e o `config.py.exemplo` antigos traziam uma `SECRET_KEY` concreta e uma senha da equipe como valores padrão.
   - Se a produção usava esses valores, qualquer pessoa com acesso ao repositório consegue forjar a sessão de um administrador.
   - O sistema novo **recusa subir** com esses valores (compara por hash). Então, antes do deploy:
     - tire `SECRET_KEY` do ambiente, para o sistema gerar uma nova em `/dados/secret_key`, ou defina uma nova;
     - defina uma **senha da equipe nova**, se for manter `LOGIN_PROVISORIO=1`.
   - Todos vão precisar entrar de novo, porque a chave muda.
2. **Rotas de pautas estavam sem login.** Pelo código anterior, `/pautas/` e `/pautas/exportar-json`
   respondiam a qualquer pessoa na internet. Avalie com a área responsável se houve acesso indevido: veja
   nos logs do proxy/túnel as chamadas a `/pautas` sem sessão.
3. **Histórico do git.** Os CSVs e páginas salvas com dados reais saíram dos arquivos, mas continuam nos
   commits antigos. Com quem administra o repositório (isso reescreve o histórico de todo mundo):
   ```bash
   git filter-repo --invert-paths --path pautaCatListCsv.csv --path pautaList-30_09_2026.csv --path "Pautas.mhtml" --path "Configuração de Pautas.mhtml" --path pautas_home.mhtml
   git push --force --all
   ```
   Depois, cada pessoa clona de novo. Confira também quem tem acesso ao repositório.
4. **Administradores sem senha individual** não entram mais pela senha da equipe. Antes do deploy, garanta
   que cada admin tem senha (`flask redefinir-senha email@...`, ou outro admin pela tela).
5. **Publicação na internet** (domínio gratuito, sem barreira antes do login): decisão para a TI e a área de proteção de dados.

## Commits sugeridos (nesta ordem)

1. **Dados:**
   - remove CSVs e páginas salvas do TM e do SharePoint, e o `LEIA-ME.txt` do pacote de teste;
   - `.gitignore` passa a bloquear `*.csv`, `*.xls*`, `*.mhtml`;
   - tabela de prazos limpa em `app/dados/pautas_sla.csv` (só categoria e horas, 853 categorias);
   - nomes de colegas saem do código (`PAUTAS_MEMBROS_UNIDADE` no `config.py`).
2. **Segurança:**
   - chave das sessões gerada e guardada na pasta de dados, e recusa de valores publicados;
   - sem segredos padrão no compose, no service e no exemplo;
   - transição pela senha da equipe só com `LOGIN_PROVISORIO=1` (agora desligado por padrão) e nunca para admin;
   - limite de tentativas no login e senha mínima de 10 caracteres;
   - cabeçalhos HSTS, X-Frame-Options, nosniff e Referrer-Policy;
   - `@login_obrigatorio` em todas as rotas de pautas e envio de pautas só para admin;
   - CSRF também em `fetch` (`X-CSRF-Token`), o que conserta o salvar observação da pauta, que dava erro 400;
   - observação mostrada com `textContent`.
3. **Migrações:**
   - `a750f5567f2c` (organizar por, lançado na Egali) e `11a6fad7f26a` (senha e pautas, idempotente);
   - sai o `ALTER TABLE` do evento de conexão;
   - Dockerfile não sobe se `flask db upgrade` falhar.
4. **Funções novas:** tipo de visto, "Organizar por", quadro por aluno em dropdown por embarque, Concluídas, Para lançar na Egali e tarefas fora do período desmarcadas por padrão.
5. **Testes:**
   - 271 testes, com amostras fictícias de pautas em `tests/amostras/`;
   - os testes de login foram adaptados ao login por e-mail e senha;
   - testes novos para login obrigatório, envio só admin, CSRF no fetch, chave gerada e recusa de valores publicados.
6. **Documentação:**
   - AGENTS.md com regras de negócio e de segurança, e `docs/REGRAS_CHECKLIST.md`;
   - README e ESTRUTURA corrigidos;
   - `scripts/iniciar_local.ps1` sem a chamada ao modo equipe, que não existe aqui.

## Conferido

- Nenhum CSV, planilha, `.mhtml`, banco ou `config.py` no pacote, fora `app/dados/pautas_sla.csv` e as amostras fictícias.
- Nenhum nome de aluno, nem de colega no código ou nos testes. O único nome de pessoa que ficou é o do autor, em `relatorio_produtividade_ia_crm.md`.
- Nenhuma chave ou senha por extenso no repositório. Só as impressões digitais (SHA-256) usadas para recusar os valores antigos.
